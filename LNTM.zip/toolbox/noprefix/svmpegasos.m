function varargout = svmpegasos(varargin)
% VL_SVMPEGASOS [deprecated]
% VL_SVMPEGASOS is deprecated. Please use VL_SVMTRAIN() instead.
[varargout{1:nargout}] = vl_svmpegasos(varargin{:});

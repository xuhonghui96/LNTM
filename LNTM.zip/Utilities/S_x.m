function  y    =    S_x( x, mu, gamma, L  )


y = gamma*Regularization2(x);

y  =    y(:)  +  mu*x;


function b=Regularization2(u)
 b = (L*(L*u));
end

end
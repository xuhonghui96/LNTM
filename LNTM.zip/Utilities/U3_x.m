function  y    =    U3_x( x, mu, beta, L )


y1 = beta * L * x;
% y2= gamma* Regularization(x);
y  =    y1(:)  +  mu*x;
% y=beta * Regularization(x);

% function f=Regularization(u)
%     f=(L2*(L2*u));
% end
end
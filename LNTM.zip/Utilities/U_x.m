function  y    =    U_x( x, mu, beta, W,px,py,sz  )

r=sz(1)*sz(2);
% W=assemble_weight_new(W,px,py,sz(1),sz(2)); 
D=sum(W,2);
% D1=D.^(-1);
% D2=D.^(-0.5);
D=sparse(1:r,1:r,D,r,r);
% D1=sparse(1:r,1:r,D1,r,r);
% D2=sparse(1:r,1:r,D2,r,r);
L=D-W;
% L1=D1*L;
% L2=D2*L*D2;

y= 0.001*Regurlarization(x);
% y = beta * L *x;

y  =    y(:)  +  mu*x;

function f=Regurlarization(u)
    f=(L*(L*u));
end

end

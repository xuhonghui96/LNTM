function  y    =    U2_x( x, mu, lambda, L  )


y = lambda * L * x;
y  =    y(:)  +  mu*x;

end

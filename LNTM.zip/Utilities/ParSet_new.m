function par = ParSet_new(sf,sz,kernel_type)
%% Parameters of FBP and block matching
par.patsize = 4;        % 
par.Pstep = 2;
par.patnum  = 60;               
par.step          =   floor((par.patsize-1));   
par.nCluster = 300; 

% par.beta = 0.01;
% par.gamma = 0.05;

%% algorithm 1  
par.beta = 0.01;
par.lambda = 0.001;     % fixed

if strcmp(kernel_type, 'Uniform_blur')
    if sf == 8
        par.lambda= 0.1;
%         par.eta = 0.05;     % under opt
        par.iter = 10;
        par.mu = 0.0004;    %0.0004 at first
        par.rho = 1.05;     %1.05 at first
    elseif sf ==16
        par.iter = 10;
        par.mu = 0.0001;
        par.rho = 1.03;
    elseif sf ==32
        par.iter = 10;
        par.mu = 0.00005;
        par.rho = 1.005;
    end
elseif strcmp(kernel_type,'Gaussian_blur')
     if sf == 4
        par.lambda = 0.005;
        par.beta = 0.01;     % under opt
        par.iter = 10;
       
    elseif sf == 8
        par.lambda = 0.05;
        par.beta = 0.03;     % under opt
        par.iter = 10;
     end
    
    par.mu = 0.0004;
    par.rho = 1.05;
end
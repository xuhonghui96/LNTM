function y=weight_ann_local(data,num_s,num_s_normal,max_compare)
% data is the patch set of an image. The local coordinates are already
% included

[m,n]=size(data);
kdtree = vl_kdtreebuild(data);

[idx, dist] = vl_kdtreequery(kdtree, data, data, 'NumNeighbors', num_s, 'MaxComparisons', max_compare);

sigma=sparse([1:n],[1:n],1./dist(num_s_normal,:),n,n);

id_row=repmat([1:n],num_s,1);
id_col=double(idx);
w=exp(-(dist*sigma).^2);
y=sparse(id_row,id_col,w,n,n);
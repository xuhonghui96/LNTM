function patch = image2patch_3d_local(H,px,py,scale,image_scale)
% H is the HSI
% px and py are spatial patches
% scale is the scale of the local weight
[m,n,B]=size(H);
patch=zeros(B*px*py,m*n);
for j=1:B
    patch((j-1)*px*py+1:j*px*py,:)=image2patch_2d(H(:,:,j),px,py);
end
% temp=repmat(1:m,1,n);
% patch(end-1,:)=px*temp*scale*image_scale/m;
% temp=repmat(1:n,m,1);
% patch(end,:)=py*reshape(temp,1,[])*scale*image_scale/n;


function [predenoised_blocks ,bparams] = Extpatch( MSI, patchsize,overlap )
bparams.block_sz = [patchsize, patchsize];
 bparams.overlap_sz=[overlap overlap];
[nr, nc,~]=size(MSI);
bparams.sz=[nr nc];
sz=[nr nc];
% num1=ceil((nr-patchsize)/(patchsize-overlap))+1;
% num2=ceil((nc-patchsize)/(patchsize-overlap))+1;
%  bparams.block_num=[num1 num2]; 
step=patchsize-overlap;
sz1=[1:step:sz(1)- bparams.block_sz(1)+1];
 sz1=[sz1 sz(1)- bparams.block_sz(1)+1];
sz2=[1:step:sz(2)- bparams.block_sz(2)+1];
sz2=[sz2 sz(2)- bparams.block_sz(2)+1];
bparams.block_num(1)=length(sz1);
bparams.block_num(2)=length(sz2);

predenoised_blocks = ExtractBlocks1(MSI, bparams);



end